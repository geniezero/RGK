<%@ Language="VBScript" %>
<%
' ============================================================
' utilisateurs.asp - Gestion des utilisateurs
' ============================================================
%>
<!-- #include file="includes/auth.asp" -->
<!-- #include file="includes/connexion.asp" -->
<%
Call VerifierSession()
pageTitle = "Gestion des utilisateurs"

Dim msg, msgType, action, rs, sql
msg     = ""
msgType = "success"
action  = Request.QueryString("action")

' ── TRAITEMENT DES FORMULAIRES ──────────────────────────────

' Création d'un utilisateur
If Request.Form("action") = "creer" Then
    Dim login, email, mdp, role
    login = Trim(Request.Form("login"))
    email = Trim(Request.Form("email"))
    mdp   = Trim(Request.Form("mdp"))
    role  = Trim(Request.Form("role"))

    If login = "" Or email = "" Or mdp = "" Then
        msg = "Tous les champs obligatoires doivent être remplis."
        msgType = "error"
    Else
        ' Vérifier doublon login
        sql = "SELECT COUNT(*) FROM utilisateurs WHERE login='" & Replace(login,"'","''") & "'"
        Set rs = oConn.Execute(sql) 
        If rs(0) > 0 Then
            msg = "Ce login est déjà utilisé."
            msgType = "error"
        Else
            ' Insérer — en prod : hacher le mdp avec BCrypt ou SHA-256
            sql = "INSERT INTO utilisateurs (login, email, mdp_hash, role, actif, date_creation) " & _
                  "VALUES ('" & Replace(login,"'","''") & "','" & Replace(email,"'","''") & "'," & _
                  "'" & Replace(mdp,"'","''") & "','" & role & "', 1, GETDATE())"
            oConn.Execute sql
            msg = "Utilisateur « " & login & " » créé avec succès."
        End If
        rs.Close
    End If
End If

' Modification
If Request.Form("action") = "modifier" Then
    Dim uid, uLogin, uEmail, uRole, uActif
    uid    = CLng(Request.Form("id"))
    uLogin = Trim(Request.Form("login"))
    uEmail = Trim(Request.Form("email"))
    uRole  = Trim(Request.Form("role"))
    uActif = IIf(Request.Form("actif") = "1", 1, 0)

    sql = "UPDATE utilisateurs SET login='" & Replace(uLogin,"'","''") & "'," & _
          "email='" & Replace(uEmail,"'","''") & "'," & _
          "role='" & uRole & "',actif=" & uActif & " WHERE id=" & uid
    oConn.Execute sql
    msg = "Utilisateur modifié avec succès."
End If

' Suppression
If Request.QueryString("supprimer") <> "" Then
    Dim delId : delId = CLng(Request.QueryString("supprimer"))
    If delId <> Session("admin_id") Then
        oConn.Execute "DELETE FROM utilisateurs WHERE id=" & delId
        msg = "Utilisateur supprimé."
    Else
        msg = "Vous ne pouvez pas supprimer votre propre compte."
        msgType = "error"
    End If
End If

' Basculer actif/inactif
If Request.QueryString("toggle") <> "" Then
    Dim togId : togId = CLng(Request.QueryString("toggle"))
    oConn.Execute "UPDATE utilisateurs SET actif = 1 - actif WHERE id=" & togId
    msg = "Statut mis à jour."
End If

' ── CHARGEMENT ──────────────────────────────────────────────
Dim recherche, filtre
recherche = Trim(Request.QueryString("q"))
filtre    = ""
If recherche <> "" Then
    filtre = " WHERE login LIKE '%" & Replace(recherche,"'","''") & "%' OR email LIKE '%" & Replace(recherche,"'","''") & "%'"
End If

sql = "SELECT id, login, email, role, actif, date_creation FROM utilisateurs" & filtre & " ORDER BY date_creation DESC"
Set rs = oConn.Execute(sql)

' Charger l'utilisateur à modifier si demandé
Dim rsEdit
If action = "editer" And Request.QueryString("id") <> "" Then
    Dim editId : editId = CLng(Request.QueryString("id"))
    sql = "SELECT * FROM utilisateurs WHERE id=" & editId
    Set rsEdit = oConn.Execute(sql)
End If
%>
<!-- #include file="includes/header.asp" -->
<!-- #include file="includes/footer_top.asp" -->

<% If msg <> "" Then %>
<div class="alert alert-<%= IIf(msgType="error","error","success") %>">
    <%= IIf(msgType="error","⚠","✓") %> <%= HtmlEncode(msg) %>
</div>
<% End If %>

<!-- Barre de recherche + bouton créer -->
<div style="display:flex;gap:12px;margin-bottom:24px;align-items:center">
    <form method="GET" action="utilisateurs.asp" style="display:flex;gap:8px;flex:1">
        <input type="text" name="q" value="<%= HtmlEncode(recherche) %>" 
               class="form-control" placeholder="Rechercher par login ou email…" style="flex:1">
        <button type="submit" class="btn btn-secondary">⌕ Rechercher</button>
        <% If recherche <> "" Then %>
        <a href="utilisateurs.asp" class="btn btn-secondary">✕ Effacer</a>
        <% End If %>
    </form>
    <button class="btn btn-primary" onclick="ouvrirModal('modalCreer')">+ Nouvel utilisateur</button>
</div>

<!-- Tableau utilisateurs -->
<div class="card">
    <div class="card-title">
        <span>◉ Utilisateurs <% If recherche <> "" Then %><span style="color:var(--muted);font-size:12px">— recherche : "<%= HtmlEncode(recherche) %>"</span><% End If %></span>
    </div>
    <% If rs.EOF Then %>
    <div class="empty-state">
        <div class="icon">◉</div>
        <p>Aucun utilisateur trouvé.</p>
    </div>
    <% Else %>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Login</th>
                <th>Email</th>
                <th>Rôle</th>
                <th>Statut</th>
                <th>Créé le</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <% Do While Not rs.EOF %>
            <tr>
                <td style="color:var(--muted)">#<%= rs("id") %></td>
                <td><strong><%= HtmlEncode(rs("login")) %></strong></td>
                <td style="color:var(--muted)"><%= HtmlEncode(rs("email")) %></td>
                <td>
                    <% If rs("role") = "admin" Then %>
                        <span class="badge badge-warn">Admin</span>
                    <% Else %>
                        <span class="badge badge-info">User</span>
                    <% End If %>
                </td>
                <td>
                    <% If rs("actif") = 1 Then %>
                        <span class="badge badge-success">Actif</span>
                    <% Else %>
                        <span class="badge badge-danger">Inactif</span>
                    <% End If %>
                </td>
                <td><%= FormatDate(rs("date_creation")) %></td>
                <td>
                    <div style="display:flex;gap:6px">
                        <a href="utilisateurs.asp?action=editer&id=<%= rs("id") %>" 
                           class="btn btn-secondary btn-sm">✎ Éditer</a>
                        <a href="utilisateurs.asp?toggle=<%= rs("id") %>" 
                           class="btn btn-secondary btn-sm"
                           title="<%= IIf(rs("actif")=1,"Désactiver","Activer") %>">
                           <%= IIf(rs("actif")=1,"⏸","▶") %>
                        </a>
                        <% If CLng(rs("id")) <> CLng(Session("admin_id")) Then %>
                        <button class="btn btn-danger btn-sm"
                            onclick="confirmerSuppression('utilisateurs.asp?supprimer=<%= rs("id") %>','<%= HtmlEncode(rs("login")) %>')">✕</button>
                        <% End If %>
                    </div>
                </td>
            </tr>
        <% rs.MoveNext : Loop %>
        </tbody>
    </table>
    <% End If %>
    <% rs.Close %>
</div>

<!-- ══ MODAL : Créer un utilisateur ══════════════════════ -->
<div class="modal-overlay" id="modalCreer">
    <div class="modal">
        <div class="modal-title">+ Nouvel utilisateur</div>
        <form method="POST" action="utilisateurs.asp">
            <input type="hidden" name="action" value="creer">
            <div class="form-group">
                <label class="form-label">Login *</label>
                <input type="text" name="login" class="form-control" placeholder="jdupont" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email *</label>
                <input type="email" name="email" class="form-control" placeholder="j.dupont@exemple.fr" required>
            </div>
            <div class="form-group">
                <label class="form-label">Mot de passe *</label>
                <input type="password" name="mdp" class="form-control" placeholder="Minimum 8 caractères" required>
            </div>
            <div class="form-group">
                <label class="form-label">Rôle</label>
                <select name="role" class="form-control">
                    <option value="user">Utilisateur</option>
                    <option value="admin">Administrateur</option>
                </select>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" onclick="fermerModal('modalCreer')">Annuler</button>
                <button type="submit" class="btn btn-primary">→ Créer</button>
            </div>
        </form>
    </div>
</div>

<!-- ══ MODAL : Éditer un utilisateur (si action=editer) ══ -->
<% If action = "editer" And Not IsEmpty(rsEdit) And Not rsEdit.EOF Then %>
<div class="modal-overlay show" id="modalEditer">
    <div class="modal">
        <div class="modal-title">✎ Modifier l'utilisateur #<%= rsEdit("id") %></div>
        <form method="POST" action="utilisateurs.asp">
            <input type="hidden" name="action" value="modifier">
            <input type="hidden" name="id" value="<%= rsEdit("id") %>">
            <div class="form-group">
                <label class="form-label">Login</label>
                <input type="text" name="login" class="form-control" 
                       value="<%= HtmlEncode(rsEdit("login")) %>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" 
                       value="<%= HtmlEncode(rsEdit("email")) %>" required>
            </div>
            <div class="form-group">
                <label class="form-label">Rôle</label>
                <select name="role" class="form-control">
                    <option value="user"  <%= IIf(rsEdit("role")="user","selected","") %>>Utilisateur</option>
                    <option value="admin" <%= IIf(rsEdit("role")="admin","selected","") %>>Administrateur</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Statut</label>
                <select name="actif" class="form-control">
                    <option value="1" <%= IIf(rsEdit("actif")=1,"selected","") %>>Actif</option>
                    <option value="0" <%= IIf(rsEdit("actif")=0,"selected","") %>>Inactif</option>
                </select>
            </div>
            <div class="modal-actions">
                <a href="utilisateurs.asp" class="btn btn-secondary">Annuler</a>
                <button type="submit" class="btn btn-primary">→ Enregistrer</button>
            </div>
        </form>
    </div>
</div>
<% rsEdit.Close : Set rsEdit = Nothing : End If %>

<!-- #include file="includes/footer.asp" -->
<%
oConn.Close : Set oConn = Nothing
%>

<%@ Language="VBScript" %>
<%
' ============================================================
' index.asp - Tableau de bord principal
' ============================================================
%>
<!-- #include file="includes/auth.asp" -->
<!-- #include file="includes/connexion.asp" -->
<%
Call VerifierSession()
pageTitle = "Dashboard"

' --- Statistiques ---
Dim nbUtilisateurs, nbFichiers, tailleTotale, nbUploadsAujourdhui
Dim rs, sql

sql = "SELECT COUNT(*) FROM utilisateurs"
Set rs = oConn.Execute(sql)
nbUtilisateurs = rs(0) : rs.Close

sql = "SELECT COUNT(*), SUM(taille) FROM fichiers"
Set rs = oConn.Execute(sql)
nbFichiers   = rs(0)
tailleTotale = rs(1) : rs.Close

sql = "SELECT COUNT(*) FROM fichiers WHERE CONVERT(date, date_upload) = CONVERT(date, GETDATE())"
Set rs = oConn.Execute(sql)
nbUploadsAujourdhui = rs(0) : rs.Close

' Dernières activités
sql = "SELECT TOP 8 f.nom_fichier, f.date_upload, u.login, f.taille " & _
      "FROM fichiers f INNER JOIN utilisateurs u ON f.utilisateur_id = u.id " & _
      "ORDER BY f.date_upload DESC"
Set rsActivite = oConn.Execute(sql)
%>
<!-- #include file="includes/header.asp" -->
<!-- #include file="includes/footer_top.asp" -->

<div class="stat-grid">
    <div class="stat-card">
        <div class="stat-value"><%= nbUtilisateurs %></div>
        <div class="stat-label">◉ Utilisateurs</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><%= nbFichiers %></div>
        <div class="stat-label">◫ Fichiers stockés</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><%= FormatTaille(tailleTotale) %></div>
        <div class="stat-label">◈ Volume total</div>
    </div>
    <div class="stat-card">
        <div class="stat-value"><%= nbUploadsAujourdhui %></div>
        <div class="stat-label">◷ Uploads aujourd'hui</div>
    </div>
</div>

<div class="card">
    <div class="card-title">
        <span>◷ Activité récente</span>
        <a href="historique.asp" class="btn btn-secondary btn-sm">Tout voir →</a>
    </div>
    <% If rsActivite.EOF Then %>
    <div class="empty-state">
        <div class="icon">◫</div>
        <p>Aucune activité pour le moment.</p>
    </div>
    <% Else %>
    <table>
        <thead>
            <tr>
                <th>Fichier</th>
                <th>Uploadé par</th>
                <th>Taille</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
        <% Do While Not rsActivite.EOF %>
            <tr>
                <td>
                    <%
                    Dim ext : ext = LCase(Right(rsActivite("nom_fichier"), 4))
                    Dim icone, cls
                    Select Case ext
                        Case ".pdf"  : icone = "📄" : cls = "ext-pdf"
                        Case ".jpg", ".png", ".gif", ".webp" : icone = "🖼" : cls = "ext-img"
                        Case ".doc", ".docx" : icone = "📝" : cls = "ext-doc"
                        Case ".zip", ".rar"  : icone = "📦" : cls = "ext-zip"
                        Case Else    : icone = "📎" : cls = "ext-other"
                    End Select
                    %>
                    <span class="file-icon <%= cls %>"><%= icone %></span>
                    <%= HtmlEncode(rsActivite("nom_fichier")) %>
                </td>
                <td><span class="badge badge-info"><%= HtmlEncode(rsActivite("login")) %></span></td>
                <td><%= FormatTaille(rsActivite("taille")) %></td>
                <td><%= FormatDate(rsActivite("date_upload")) %></td>
            </tr>
        <% rsActivite.MoveNext : Loop : rsActivite.Close %>
        </tbody>
    </table>
    <% End If %>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">
    <div class="card" style="margin-bottom:0">
        <div class="card-title"><span>◉ Accès rapide — Utilisateurs</span></div>
        <a href="utilisateurs.asp" class="btn btn-secondary" style="display:block;text-align:center;margin-bottom:10px">Gérer les comptes</a>
        <a href="utilisateurs.asp?action=nouveau" class="btn btn-primary" style="display:block;text-align:center">+ Nouvel utilisateur</a>
    </div>
    <div class="card" style="margin-bottom:0">
        <div class="card-title"><span>◫ Accès rapide — Fichiers</span></div>
        <a href="uploads.asp" class="btn btn-secondary" style="display:block;text-align:center;margin-bottom:10px">Gérer les fichiers</a>
        <a href="uploads.asp?action=upload" class="btn btn-primary" style="display:block;text-align:center">+ Uploader un fichier</a>
    </div>
</div>

<!-- #include file="includes/footer.asp" -->
<%
oConn.Close : Set oConn = Nothing
%>

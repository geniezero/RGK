<%@ Language="VBScript" %>
<%
' ============================================================
' uploads.asp - Gestion des fichiers uploadés
' ============================================================
' Prérequis : composant Persits ASPUpload ou SA-FileUp installé.
' Ce code utilise l'approche Request.BinaryRead + FSO en fallback,
' mais montre aussi la syntaxe ASPUpload commentée.
' ============================================================
%>
<!-- #include file="includes/auth.asp" -->
<!-- #include file="includes/connexion.asp" -->
<%
Call VerifierSession()
pageTitle = "Gestion des fichiers"

Dim msg, msgType, action
msg     = ""
msgType = "success"
action  = Request.QueryString("action")

' Répertoire d'upload (chemin physique)
Dim uploadDir
uploadDir = Server.MapPath("uploads/")

' Extensions autorisées
Dim extsAuthorisees
extsAuthorisees = Array("pdf","doc","docx","xls","xlsx","ppt","pptx","jpg","jpeg","png","gif","webp","zip","rar","txt","csv")

Function ExtAutorisee(nom)
    Dim ext, i
    ext = LCase(Mid(nom, InStrRev(nom, ".") + 1))
    For i = 0 To UBound(extsAuthorisees)
        If extsAuthorisees(i) = ext Then ExtAutorisee = True : Exit Function
    Next
    ExtAutorisee = False
End Function

' ── SUPPRESSION ─────────────────────────────────────────────
If Request.QueryString("supprimer") <> "" Then
    Dim delId : delId = CLng(Request.QueryString("supprimer"))
    Dim rsFile, cheminFichier
    Set rsFile = oConn.Execute("SELECT chemin_physique FROM fichiers WHERE id=" & delId)
    If Not rsFile.EOF Then
        cheminFichier = rsFile("chemin_physique")
        rsFile.Close
        ' Supprimer le fichier physique
        Dim fso : Set fso = Server.CreateObject("Scripting.FileSystemObject")
        If fso.FileExists(cheminFichier) Then fso.DeleteFile cheminFichier
        Set fso = Nothing
        ' Supprimer l'enregistrement BDD
        oConn.Execute "DELETE FROM fichiers WHERE id=" & delId
        msg = "Fichier supprimé avec succès."
    Else
        rsFile.Close
        msg = "Fichier introuvable en base."
        msgType = "error"
    End If
End If

' ── UPLOAD ──────────────────────────────────────────────────
' Méthode : ASPUpload (Persits.Upload)
' Décommenter ce bloc si ASPUpload est installé :
'
' If Request.ServerVariables("REQUEST_METHOD") = "POST" And action = "upload" Then
'     Dim Upload
'     Set Upload = Server.CreateObject("Persits.Upload")
'     Upload.Save uploadDir
'     Dim f
'     For Each f In Upload.Files
'         If Not ExtAutorisee(f.OriginalFileName) Then
'             msg = "Extension non autorisée : " & f.OriginalFileName
'             msgType = "error"
'         Else
'             Dim nomUnique
'             nomUnique = Year(Now) & Month(Now) & Day(Now) & "_" & Hour(Now) & Minute(Now) & Second(Now) & "_" & f.OriginalFileName
'             f.SaveAs uploadDir & nomUnique
'             sql = "INSERT INTO fichiers (nom_fichier, nom_stockage, chemin_physique, taille, utilisateur_id, date_upload) " & _
'                   "VALUES ('" & Replace(f.OriginalFileName,"'","''") & "','" & nomUnique & "'," & _
'                   "'" & Replace(uploadDir & nomUnique,"'","''") & "'," & f.Size & "," & Session("admin_id") & ",GETDATE())"
'             oConn.Execute sql
'             msg = "Fichier « " & f.OriginalFileName & " » uploadé avec succès."
'         End If
'     Next
' End If

' ── CHARGEMENT DE LA LISTE ──────────────────────────────────
Dim rechercheF, filtreF, sql, rs
rechercheF = Trim(Request.QueryString("q"))
filtreF = " WHERE 1=1"
If rechercheF <> "" Then
    filtreF = filtreF & " AND (f.nom_fichier LIKE '%" & Replace(rechercheF,"'","''") & "%' OR u.login LIKE '%" & Replace(rechercheF,"'","''") & "%')"
End If

' Filtre par type
Dim filtreExt : filtreExt = Trim(Request.QueryString("ext"))
If filtreExt <> "" Then
    filtreF = filtreF & " AND f.nom_fichier LIKE '%." & Replace(filtreExt,"'","''") & "'"
End If

sql = "SELECT f.id, f.nom_fichier, f.taille, f.date_upload, u.login " & _
      "FROM fichiers f INNER JOIN utilisateurs u ON f.utilisateur_id = u.id" & _
      filtreF & " ORDER BY f.date_upload DESC"
Set rs = oConn.Execute(sql)
%>
<!-- #include file="includes/header.asp" -->
<!-- #include file="includes/footer_top.asp" -->

<% If msg <> "" Then %>
<div class="alert alert-<%= IIf(msgType="error","error","success") %>">
    <%= IIf(msgType="error","⚠","✓") %> <%= HtmlEncode(msg) %>
</div>
<% End If %>

<!-- Barre d'outils -->
<div style="display:flex;gap:12px;margin-bottom:24px;align-items:center;flex-wrap:wrap">
    <form method="GET" action="uploads.asp" style="display:flex;gap:8px;flex:1;min-width:200px">
        <input type="text" name="q" value="<%= HtmlEncode(rechercheF) %>" 
               class="form-control" placeholder="Rechercher un fichier ou utilisateur…" style="flex:1">
        <% If filtreExt <> "" Then %>
        <input type="hidden" name="ext" value="<%= HtmlEncode(filtreExt) %>">
        <% End If %>
        <button type="submit" class="btn btn-secondary">⌕</button>
        <% If rechercheF <> "" Or filtreExt <> "" Then %>
        <a href="uploads.asp" class="btn btn-secondary">✕</a>
        <% End If %>
    </form>
    <!-- Filtres rapides par extension -->
    <div style="display:flex;gap:6px">
        <a href="uploads.asp?ext=pdf"  class="btn btn-secondary btn-sm <%= IIf(filtreExt="pdf","btn-primary","") %>">PDF</a>
        <a href="uploads.asp?ext=jpg"  class="btn btn-secondary btn-sm <%= IIf(filtreExt="jpg","btn-primary","") %>">IMG</a>
        <a href="uploads.asp?ext=docx" class="btn btn-secondary btn-sm <%= IIf(filtreExt="docx","btn-primary","") %>">DOCX</a>
        <a href="uploads.asp?ext=zip"  class="btn btn-secondary btn-sm <%= IIf(filtreExt="zip","btn-primary","") %>">ZIP</a>
    </div>
    <button class="btn btn-primary" onclick="ouvrirModal('modalUpload')">↑ Uploader un fichier</button>
</div>

<div class="card">
    <div class="card-title">
        <span>◫ Fichiers uploadés
        <% If rechercheF <> "" Or filtreExt <> "" Then %>
        <span style="color:var(--muted);font-size:12px">— filtrés</span>
        <% End If %>
        </span>
    </div>
    <% If rs.EOF Then %>
    <div class="empty-state">
        <div class="icon">◫</div>
        <p>Aucun fichier trouvé.</p>
    </div>
    <% Else %>
    <table>
        <thead>
            <tr>
                <th>Fichier</th>
                <th>Type</th>
                <th>Taille</th>
                <th>Uploadé par</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <% Do While Not rs.EOF %>
        <%
            Dim nomF, extF, iconeF, clsF
            nomF = rs("nom_fichier")
            If InStrRev(nomF, ".") > 0 Then
                extF = LCase(Mid(nomF, InStrRev(nomF, ".") + 1))
            Else
                extF = ""
            End If
            Select Case extF
                Case "pdf"              : iconeF = "📄" : clsF = "ext-pdf"
                Case "jpg","jpeg","png","gif","webp" : iconeF = "🖼" : clsF = "ext-img"
                Case "doc","docx"       : iconeF = "📝" : clsF = "ext-doc"
                Case "xls","xlsx","csv" : iconeF = "📊" : clsF = "ext-other"
                Case "zip","rar"        : iconeF = "📦" : clsF = "ext-zip"
                Case Else               : iconeF = "📎" : clsF = "ext-other"
            End Select
        %>
            <tr>
                <td>
                    <span class="file-icon <%= clsF %>"><%= iconeF %></span>
                    <%= HtmlEncode(nomF) %>
                </td>
                <td><span class="badge badge-info"><%= UCase(extF) %></span></td>
                <td><%= FormatTaille(rs("taille")) %></td>
                <td><span class="badge badge-warn"><%= HtmlEncode(rs("login")) %></span></td>
                <td><%= FormatDate(rs("date_upload")) %></td>
                <td>
                    <div style="display:flex;gap:6px">
                        <a href="uploads/<%= HtmlEncode(rs("nom_fichier")) %>" 
                           class="btn btn-secondary btn-sm" target="_blank" title="Télécharger">↓</a>
                        <button class="btn btn-danger btn-sm"
                            onclick="confirmerSuppression('uploads.asp?supprimer=<%= rs("id") %>','<%= HtmlEncode(nomF) %>')">✕</button>
                    </div>
                </td>
            </tr>
        <% rs.MoveNext : Loop %>
        </tbody>
    </table>
    <% End If %>
    <% rs.Close %>
</div>

<!-- ══ MODAL : Upload ═════════════════════════════════════ -->
<div class="modal-overlay" id="modalUpload">
    <div class="modal">
        <div class="modal-title">↑ Uploader un fichier</div>
        <p style="color:var(--muted);font-size:11px;margin-bottom:20px">
            Extensions acceptées : PDF, DOC, DOCX, XLS, XLSX, JPG, PNG, GIF, ZIP, RAR, TXT, CSV<br>
            Taille maximale : 20 Mo
        </p>
        <!--
            action="uploads_process.asp" : page dédiée au traitement multipart
            enctype obligatoire pour les uploads de fichiers
        -->
        <form method="POST" action="uploads_process.asp" enctype="multipart/form-data">
            <div class="form-group">
                <label class="form-label">Sélectionner le fichier *</label>
                <input type="file" name="fichier" class="form-control" required
                       accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.gif,.webp,.zip,.rar,.txt,.csv">
            </div>
            <div class="form-group">
                <label class="form-label">Description (optionnel)</label>
                <input type="text" name="description" class="form-control" placeholder="Brève description du fichier">
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-secondary" onclick="fermerModal('modalUpload')">Annuler</button>
                <button type="submit" class="btn btn-primary">↑ Uploader</button>
            </div>
        </form>
    </div>
</div>

<% If action = "upload" Then %>
<script>document.addEventListener('DOMContentLoaded', function(){ ouvrirModal('modalUpload'); })</script>
<% End If %>

<!-- #include file="includes/footer.asp" -->
<%
oConn.Close : Set oConn = Nothing
%>

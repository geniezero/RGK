<%@ Language="VBScript" %>
<%
' ============================================================
' login.asp - Page de connexion administrateur
' ============================================================
Session.Abandon

Dim erreur, login, mdp
erreur = ""

If Request.Form("action") = "login" Then
    login = Trim(Request.Form("login"))
    mdp   = Trim(Request.Form("mdp"))

    ' --- Remplacer par une vraie vérification BDD ---
    If login = "admin" And mdp = "Admin123!" Then
        Session("admin_connecte") = True
        Session("admin_login")    = login
        Session("admin_id")       = 1
        Response.Redirect "index.asp"
    Else
        erreur = "Identifiants incorrects. Veuillez réessayer."
    End If
End If
%>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>AdminPanel — Connexion</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700;800&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        :root{--bg:#0a0c10;--surface:#111318;--border:#252830;--accent:#e8ff47;--danger:#ff4757;--text:#e8eaf0;--muted:#6b7280}
        body{background:var(--bg);color:var(--text);font-family:'Space Mono',monospace;min-height:100vh;display:flex;align-items:center;justify-content:center;}
        .bg-grid{position:fixed;inset:0;background-image:linear-gradient(var(--border) 1px,transparent 1px),linear-gradient(90deg,var(--border) 1px,transparent 1px);background-size:40px 40px;opacity:.3;pointer-events:none}
        .login-wrap{position:relative;z-index:1;width:400px;max-width:95vw}
        .login-brand{text-align:center;margin-bottom:40px}
        .login-brand .mark{font-family:'Syne',sans-serif;font-weight:800;font-size:28px;color:var(--accent);letter-spacing:-1px}
        .login-brand .sub{font-size:11px;color:var(--muted);letter-spacing:2px;text-transform:uppercase;margin-top:4px}
        .login-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:36px}
        .login-card h1{font-family:'Syne',sans-serif;font-weight:700;font-size:20px;margin-bottom:6px}
        .login-card p{color:var(--muted);font-size:12px;margin-bottom:28px}
        .form-group{margin-bottom:18px}
        .form-label{display:block;font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:8px}
        .form-control{width:100%;background:var(--bg);border:1px solid var(--border);border-radius:8px;color:var(--text);padding:11px 14px;font-family:'Space Mono',monospace;font-size:13px;transition:border-color .15s}
        .form-control:focus{outline:none;border-color:var(--accent)}
        .btn{width:100%;padding:12px;border-radius:8px;background:var(--accent);color:#000;font-family:'Space Mono',monospace;font-weight:700;font-size:13px;cursor:pointer;border:none;transition:background .15s}
        .btn:hover{background:#d4e83f}
        .alert{padding:12px 14px;border-radius:8px;margin-bottom:20px;font-size:12px;background:rgba(255,71,87,.1);border:1px solid var(--danger);color:var(--danger)}
        .hint{text-align:center;margin-top:20px;font-size:11px;color:var(--muted)}
        .hint code{background:rgba(232,255,71,.1);color:var(--accent);padding:2px 6px;border-radius:4px}
    </style>
</head>
<body>
<div class="bg-grid"></div>
<div class="login-wrap">
    <div class="login-brand">
        <div class="mark">⬡ AdminPanel</div>
        <div class="sub">Classic ASP — Back-office</div>
    </div>
    <div class="login-card">
        <h1>Connexion</h1>
        <p>Accès réservé aux administrateurs autorisés.</p>

        <% If erreur <> "" Then %>
        <div class="alert">⚠ <%= Server.HTMLEncode(erreur) %></div>
        <% End If %>

        <form method="POST" action="login.asp">
            <input type="hidden" name="action" value="login">
            <div class="form-group">
                <label class="form-label">Identifiant</label>
                <input type="text" name="login" class="form-control" placeholder="admin" autocomplete="username" required>
            </div>
            <div class="form-group">
                <label class="form-label">Mot de passe</label>
                <input type="password" name="mdp" class="form-control" placeholder="••••••••" autocomplete="current-password" required>
            </div>
            <button type="submit" class="btn">→ Se connecter</button>
        </form>
        <div class="hint">Démo : <code>admin</code> / <code>Admin123!</code></div>
    </div>
</div>
</body>
</html>

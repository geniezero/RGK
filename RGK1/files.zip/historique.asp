<%@ Language="VBScript" %>
<%
' ============================================================
' historique.asp - Qui a uploadé quoi (audit complet)
' ============================================================
%>
<!-- #include file="includes/auth.asp" -->
<!-- #include file="includes/connexion.asp" -->
<%
Call VerifierSession()
pageTitle = "Historique des uploads"

Dim sql, rs, msg, msgType
msg = "" : msgType = "success"

' ── FILTRES ─────────────────────────────────────────────────
Dim filtreUser, filtreExt, dateDebut, dateFin, q
filtreUser = Trim(Request.QueryString("user"))
filtreExt  = Trim(Request.QueryString("ext"))
dateDebut  = Trim(Request.QueryString("date_debut"))
dateFin    = Trim(Request.QueryString("date_fin"))
q          = Trim(Request.QueryString("q"))

' Pagination
Dim pageSize, pageNum, offset
pageSize = 15
pageNum  = CInt(IIf(Request.QueryString("p") = "", "1", Request.QueryString("p")))
If pageNum < 1 Then pageNum = 1
offset = (pageNum - 1) * pageSize

' Construire WHERE
Dim where_clause
where_clause = " WHERE 1=1"
If q <> "" Then
    where_clause = where_clause & " AND (f.nom_fichier LIKE '%" & Replace(q,"'","''") & "%' OR u.login LIKE '%" & Replace(q,"'","''") & "%')"
End If
If filtreUser <> "" Then
    where_clause = where_clause & " AND u.login = '" & Replace(filtreUser,"'","''") & "'"
End If
If filtreExt <> "" Then
    where_clause = where_clause & " AND f.nom_fichier LIKE '%." & Replace(filtreExt,"'","''") & "'"
End If
If dateDebut <> "" Then
    where_clause = where_clause & " AND f.date_upload >= '" & Replace(dateDebut,"'","''") & "'"
End If
If dateFin <> "" Then
    where_clause = where_clause & " AND f.date_upload <= '" & Replace(dateFin,"'","''") & " 23:59:59'"
End If

' Total pour pagination
Dim total, totalPages
sql = "SELECT COUNT(*) FROM fichiers f INNER JOIN utilisateurs u ON f.utilisateur_id = u.id" & where_clause
Set rs = oConn.Execute(sql)
total = rs(0) : rs.Close
totalPages = CInt(Int((total + pageSize - 1) / pageSize))
If pageNum > totalPages And totalPages > 0 Then pageNum = totalPages : offset = (pageNum-1)*pageSize

' Requête principale avec pagination SQL Server
sql = "SELECT f.id, f.nom_fichier, f.taille, f.description, f.date_upload," & _
      " u.login, u.email, u.role" & _
      " FROM fichiers f INNER JOIN utilisateurs u ON f.utilisateur_id = u.id" & _
      where_clause & " ORDER BY f.date_upload DESC" & _
      " OFFSET " & offset & " ROWS FETCH NEXT " & pageSize & " ROWS ONLY"
Set rs = oConn.Execute(sql)

' Liste des utilisateurs pour le filtre
Dim rsUsers
Set rsUsers = oConn.Execute("SELECT DISTINCT login FROM utilisateurs ORDER BY login")

' Statistiques par utilisateur
Dim rsStat
sql = "SELECT u.login, COUNT(f.id) AS nb_fichiers, SUM(f.taille) AS volume_total " & _
      "FROM utilisateurs u LEFT JOIN fichiers f ON f.utilisateur_id = u.id " & _
      "GROUP BY u.login ORDER BY nb_fichiers DESC"
Set rsStat = oConn.Execute(sql)
%>
<!-- #include file="includes/header.asp" -->
<!-- #include file="includes/footer_top.asp" -->

<!-- Panneau stats par utilisateur -->
<div class="card">
    <div class="card-title"><span>◉ Volume par utilisateur</span></div>
    <% If rsStat.EOF Then %>
    <p style="color:var(--muted);font-size:12px">Aucune donnée.</p>
    <% Else %>
    <div style="display:flex;gap:12px;flex-wrap:wrap">
    <% Do While Not rsStat.EOF %>
        <div style="background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:14px 20px;min-width:160px">
            <div style="font-family:'Syne',sans-serif;font-weight:700;color:var(--accent);font-size:22px"><%= rsStat("nb_fichiers") %></div>
            <div style="color:var(--text);font-size:12px;margin-top:2px"><%= HtmlEncode(rsStat("login")) %></div>
            <div style="color:var(--muted);font-size:11px;margin-top:2px">
                <%= IIf(IsNull(rsStat("volume_total")), "0 o", FormatTaille(rsStat("volume_total"))) %>
            </div>
        </div>
    <% rsStat.MoveNext : Loop : rsStat.Close %>
    </div>
    <% End If %>
</div>

<!-- Barre de filtres -->
<form method="GET" action="historique.asp">
<div style="display:grid;grid-template-columns:1fr 160px 160px 140px 140px auto;gap:10px;margin-bottom:24px;align-items:end">
    <div>
        <div class="form-label">Recherche libre</div>
        <input type="text" name="q" value="<%= HtmlEncode(q) %>" class="form-control" placeholder="Nom de fichier, login…">
    </div>
    <div>
        <div class="form-label">Utilisateur</div>
        <select name="user" class="form-control">
            <option value="">— Tous —</option>
            <% rsUsers.MoveFirst
               Do While Not rsUsers.EOF %>
            <option value="<%= HtmlEncode(rsUsers("login")) %>" 
                    <%= IIf(filtreUser=rsUsers("login"),"selected","") %>>
                <%= HtmlEncode(rsUsers("login")) %>
            </option>
            <% rsUsers.MoveNext : Loop : rsUsers.Close %>
        </select>
    </div>
    <div>
        <div class="form-label">Extension</div>
        <select name="ext" class="form-control">
            <option value="">— Toutes —</option>
            <option value="pdf"  <%= IIf(filtreExt="pdf","selected","")  %>>PDF</option>
            <option value="docx" <%= IIf(filtreExt="docx","selected","") %>>DOCX</option>
            <option value="xlsx" <%= IIf(filtreExt="xlsx","selected","") %>>XLSX</option>
            <option value="jpg"  <%= IIf(filtreExt="jpg","selected","")  %>>JPG</option>
            <option value="png"  <%= IIf(filtreExt="png","selected","")  %>>PNG</option>
            <option value="zip"  <%= IIf(filtreExt="zip","selected","")  %>>ZIP</option>
        </select>
    </div>
    <div>
        <div class="form-label">Date début</div>
        <input type="date" name="date_debut" value="<%= HtmlEncode(dateDebut) %>" class="form-control">
    </div>
    <div>
        <div class="form-label">Date fin</div>
        <input type="date" name="date_fin" value="<%= HtmlEncode(dateFin) %>" class="form-control">
    </div>
    <div style="display:flex;gap:6px;padding-top:20px">
        <button type="submit" class="btn btn-primary">⌕</button>
        <a href="historique.asp" class="btn btn-secondary">✕</a>
    </div>
</div>
</form>

<!-- Tableau principal -->
<div class="card">
    <div class="card-title">
        <span>◷ Journal des uploads
            <span style="font-size:12px;color:var(--muted);font-family:'Space Mono',monospace">
                (<%= total %> résultat<%= IIf(total>1,"s","") %>)
            </span>
        </span>
        <span style="font-size:11px;color:var(--muted)">Page <%= pageNum %> / <%= IIf(totalPages=0,1,totalPages) %></span>
    </div>

    <% If rs.EOF Then %>
    <div class="empty-state">
        <div class="icon">◷</div>
        <p>Aucun résultat pour ces critères.</p>
    </div>
    <% Else %>
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Fichier</th>
                <th>Type</th>
                <th>Taille</th>
                <th>Utilisateur</th>
                <th>Rôle</th>
                <th>Date &amp; heure</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
        <% Do While Not rs.EOF %>
        <%
            Dim nomH, extH, iconeH, clsH
            nomH = rs("nom_fichier")
            If InStrRev(nomH, ".") > 0 Then
                extH = LCase(Mid(nomH, InStrRev(nomH, ".") + 1))
            Else
                extH = ""
            End If
            Select Case extH
                Case "pdf"  : iconeH = "📄" : clsH = "ext-pdf"
                Case "jpg","jpeg","png","gif","webp" : iconeH = "🖼" : clsH = "ext-img"
                Case "doc","docx" : iconeH = "📝" : clsH = "ext-doc"
                Case "xls","xlsx","csv" : iconeH = "📊" : clsH = "ext-other"
                Case "zip","rar" : iconeH = "📦" : clsH = "ext-zip"
                Case Else : iconeH = "📎" : clsH = "ext-other"
            End Select
        %>
            <tr>
                <td style="color:var(--muted)">#<%= rs("id") %></td>
                <td>
                    <span class="file-icon <%= clsH %>"><%= iconeH %></span>
                    <a href="uploads/<%= HtmlEncode(nomH) %>" target="_blank"
                       style="color:var(--text);text-decoration:none"
                       title="Télécharger"><%= HtmlEncode(nomH) %></a>
                </td>
                <td><span class="badge badge-info"><%= UCase(extH) %></span></td>
                <td><%= FormatTaille(rs("taille")) %></td>
                <td>
                    <a href="historique.asp?user=<%= HtmlEncode(rs("login")) %>"
                       style="text-decoration:none">
                    <span class="badge badge-warn"><%= HtmlEncode(rs("login")) %></span>
                    </a>
                </td>
                <td>
                    <% If rs("role") = "admin" Then %>
                    <span class="badge badge-danger">Admin</span>
                    <% Else %>
                    <span class="badge badge-success">User</span>
                    <% End If %>
                </td>
                <td style="white-space:nowrap"><%= FormatDate(rs("date_upload")) %></td>
                <td style="color:var(--muted);font-size:11px">
                    <%= IIf(IsNull(rs("description")) Or rs("description")="", "—", HtmlEncode(rs("description"))) %>
                </td>
            </tr>
        <% rs.MoveNext : Loop %>
        </tbody>
    </table>
    <% End If %>
    <% rs.Close %>

    <!-- Pagination -->
    <% If totalPages > 1 Then %>
    <div style="display:flex;justify-content:center;gap:6px;margin-top:20px;padding-top:16px;border-top:1px solid var(--border)">
        <%
        Dim p, urlBase
        urlBase = "historique.asp?" & _
                  IIf(q<>"","q="&Server.URLEncode(q)&"&","") & _
                  IIf(filtreUser<>"","user="&Server.URLEncode(filtreUser)&"&","") & _
                  IIf(filtreExt<>"","ext="&Server.URLEncode(filtreExt)&"&","") & _
                  IIf(dateDebut<>"","date_debut="&Server.URLEncode(dateDebut)&"&","") & _
                  IIf(dateFin<>"","date_fin="&Server.URLEncode(dateFin)&"&","")

        Dim pStart, pEnd
        pStart = IIf(pageNum - 2 < 1, 1, pageNum - 2)
        pEnd   = IIf(pageNum + 2 > totalPages, totalPages, pageNum + 2)

        If pageNum > 1 Then %>
        <a href="<%= urlBase %>p=<%= pageNum-1 %>" class="btn btn-secondary btn-sm">←</a>
        <% End If

        For p = pStart To pEnd %>
        <a href="<%= urlBase %>p=<%= p %>" 
           class="btn btn-sm <%= IIf(p=pageNum,"btn-primary","btn-secondary") %>"><%= p %></a>
        <% Next

        If pageNum < totalPages Then %>
        <a href="<%= urlBase %>p=<%= pageNum+1 %>" class="btn btn-secondary btn-sm">→</a>
        <% End If %>
    </div>
    <% End If %>
</div>

<!-- #include file="includes/footer.asp" -->
<%
oConn.Close : Set oConn = Nothing
%>

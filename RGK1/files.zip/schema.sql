-- ============================================================
-- schema.sql — Structure de la base de données AdminPanel
-- Compatible SQL Server 2012+
-- Pour Access : adapter les types (TEXT → MEMO, DATETIME → DATE/TIME, BIT → YES/NO)
-- ============================================================

-- Table des utilisateurs
CREATE TABLE utilisateurs (
    id             INT           IDENTITY(1,1) PRIMARY KEY,
    login          VARCHAR(50)   NOT NULL UNIQUE,
    email          VARCHAR(150)  NOT NULL,
    mdp_hash       VARCHAR(255)  NOT NULL,          -- En prod : stocker le hash bcrypt/SHA-256
    role           VARCHAR(20)   NOT NULL DEFAULT 'user',  -- 'user' ou 'admin'
    actif          BIT           NOT NULL DEFAULT 1,
    date_creation  DATETIME      NOT NULL DEFAULT GETDATE()
);

-- Table des fichiers uploadés
CREATE TABLE fichiers (
    id               INT           IDENTITY(1,1) PRIMARY KEY,
    nom_fichier      VARCHAR(255)  NOT NULL,          -- Nom original du fichier
    nom_stockage     VARCHAR(255)  NOT NULL,          -- Nom unique sur le disque
    chemin_physique  VARCHAR(500)  NOT NULL,          -- Chemin absolu serveur
    taille           BIGINT        NOT NULL DEFAULT 0, -- Taille en octets
    description      VARCHAR(500)  NULL,
    utilisateur_id   INT           NOT NULL,
    date_upload      DATETIME      NOT NULL DEFAULT GETDATE(),

    CONSTRAINT fk_fichiers_utilisateurs
        FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id)
        ON DELETE CASCADE
);

-- Index utiles
CREATE INDEX idx_fichiers_user   ON fichiers (utilisateur_id);
CREATE INDEX idx_fichiers_date   ON fichiers (date_upload DESC);
CREATE INDEX idx_utilisateurs_login ON utilisateurs (login);

-- ── DONNÉES DE DÉMO ────────────────────────────────────────
INSERT INTO utilisateurs (login, email, mdp_hash, role, actif)
VALUES
    ('admin',   'admin@exemple.fr',   'Admin123!',   'admin', 1),
    ('jdupont', 'j.dupont@exemple.fr','UserPass1!',  'user',  1),
    ('mmartin', 'm.martin@exemple.fr','UserPass2!',  'user',  1),
    ('lbernard','l.bernard@exemple.fr','UserPass3!', 'user',  0);

INSERT INTO fichiers (nom_fichier, nom_stockage, chemin_physique, taille, description, utilisateur_id)
VALUES
    ('rapport_q1.pdf',  '20240101_120000_rapport_q1.pdf',  'C:\inetpub\wwwroot\admin\uploads\20240101_120000_rapport_q1.pdf',  245760, 'Rapport Q1 2024', 2),
    ('photo_equipe.jpg','20240115_140000_photo_equipe.jpg', 'C:\inetpub\wwwroot\admin\uploads\20240115_140000_photo_equipe.jpg', 1048576, 'Photo de l équipe', 3),
    ('budget_2024.xlsx','20240201_090000_budget_2024.xlsx', 'C:\inetpub\wwwroot\admin\uploads\20240201_090000_budget_2024.xlsx', 512000, 'Budget prévisionnel', 1),
    ('contrat.pdf',     '20240210_100000_contrat.pdf',      'C:\inetpub\wwwroot\admin\uploads\20240210_100000_contrat.pdf',      307200, 'Contrat fournisseur', 2),
    ('logo.png',        '20240301_160000_logo.png',         'C:\inetpub\wwwroot\admin\uploads\20240301_160000_logo.png',         89600,  'Logo entreprise', 3);

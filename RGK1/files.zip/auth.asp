<%
' ============================================================
' auth.asp - Vérification de session administrateur
' ============================================================
Sub VerifierSession()
    If Session("admin_connecte") <> True Then
        Response.Redirect "login.asp"
    End If
End Sub

Function HtmlEncode(valeur)
    HtmlEncode = Server.HTMLEncode(valeur)
End Function

Function FormatDate(d)
    If IsDate(d) Then
        FormatDate = Day(d) & "/" & Month(d) & "/" & Year(d) & " " & Hour(d) & "h" & Right("0" & Minute(d), 2)
    Else
        FormatDate = "—"
    End If
End Function

Function FormatTaille(octets)
    If octets < 1024 Then
        FormatTaille = octets & " o"
    ElseIf octets < 1048576 Then
        FormatTaille = Round(octets / 1024, 1) & " Ko"
    Else
        FormatTaille = Round(octets / 1048576, 1) & " Mo"
    End If
End Function
%>

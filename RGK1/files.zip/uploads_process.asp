<%@ Language="VBScript" %>
<%
' ============================================================
' uploads_process.asp - Traitement de l'upload multipart
' ============================================================
' Ce fichier reçoit le POST multipart/form-data et enregistre
' le fichier + les méta-données en base.
'
' ⚠ PRÉREQUIS : Composant ASPUpload (Persits.Upload) installé.
'   Téléchargement : https://www.aspupload.com/
'   Alternative gratuite : Free ASP Upload (pure ASP)
' ============================================================
%>
<!-- #include file="includes/auth.asp" -->
<!-- #include file="includes/connexion.asp" -->
<%
Call VerifierSession()

Dim msg, msgType, uploadDir, tailleMax
uploadDir = Server.MapPath("uploads/")
tailleMax = 20971520 ' 20 Mo en octets

' Extensions autorisées
Dim extsOk
extsOk = "|pdf|doc|docx|xls|xlsx|ppt|pptx|jpg|jpeg|png|gif|webp|zip|rar|txt|csv|"

Function ExtOk(nom)
    Dim ext
    ext = LCase(Mid(nom, InStrRev(nom, ".") + 1))
    ExtOk = (InStr(extsOk, "|" & ext & "|") > 0)
End Function

Function NomUnique(original)
    Dim base, ext, ts
    ts   = Year(Now) & Right("0"&Month(Now),2) & Right("0"&Day(Now),2) & _
           "_" & Right("0"&Hour(Now),2) & Right("0"&Minute(Now),2) & Right("0"&Second(Now),2)
    If InStrRev(original, ".") > 0 Then
        base = Left(original, InStrRev(original,".") - 1)
        ext  = Mid(original, InStrRev(original,"."))
    Else
        base = original : ext = ""
    End If
    NomUnique = ts & "_" & base & ext
End Function

' ── TRAITEMENT AVEC ASPUpload ────────────────────────────────
On Error Resume Next

Dim Upload
Set Upload = Server.CreateObject("Persits.Upload")

If Err.Number <> 0 Then
    ' Composant non installé — redirection avec erreur
    Response.Redirect "uploads.asp?msg=composant_manquant"
End If

On Error GoTo 0

Upload.MaxBytes = tailleMax
Upload.Save uploadDir

Dim f, erreurs, nbOk
erreurs = ""
nbOk = 0

For Each f In Upload.Files
    If Not ExtOk(f.OriginalFileName) Then
        erreurs = erreurs & "Extension refusée : " & f.OriginalFileName & ". "
    ElseIf f.Size > tailleMax Then
        erreurs = erreurs & "Fichier trop lourd : " & f.OriginalFileName & ". "
    Else
        Dim nomStocke, cheminComplet
        nomStocke    = NomUnique(f.OriginalFileName)
        cheminComplet = uploadDir & nomStocke

        f.SaveAs cheminComplet

        Dim desc
        desc = Trim(Upload.Form("description"))

        Dim sql
        sql = "INSERT INTO fichiers " & _
              "(nom_fichier, nom_stockage, chemin_physique, taille, description, utilisateur_id, date_upload) " & _
              "VALUES (" & _
              "'" & Replace(f.OriginalFileName,"'","''") & "'," & _
              "'" & Replace(nomStocke,"'","''") & "'," & _
              "'" & Replace(cheminComplet,"'","''") & "'," & _
              f.Size & "," & _
              "'" & Replace(desc,"'","''") & "'," & _
              CLng(Session("admin_id")) & "," & _
              "GETDATE())"
        oConn.Execute sql
        nbOk = nbOk + 1
    End If
Next

oConn.Close : Set oConn = Nothing

If erreurs <> "" Then
    Session("flash_msg")  = "Erreur(s) : " & erreurs
    Session("flash_type") = "error"
Else
    Session("flash_msg")  = nbOk & " fichier(s) uploadé(s) avec succès."
    Session("flash_type") = "success"
End If

Response.Redirect "uploads.asp"
%>

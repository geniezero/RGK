<%
' ============================================================
' header.asp - En-tête et navigation commune
' ============================================================
Dim activeTab
If InStr(Request.ServerVariables("SCRIPT_NAME"), "utilisateurs") > 0 Then
    activeTab = "users"
ElseIf InStr(Request.ServerVariables("SCRIPT_NAME"), "uploads") > 0 Then
    activeTab = "uploads"
ElseIf InStr(Request.ServerVariables("SCRIPT_NAME"), "historique") > 0 Then
    activeTab = "historique"
Else
    activeTab = "dashboard"
End If
%>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AdminPanel — <%= pageTitle %></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --bg:        #0a0c10;
            --surface:   #111318;
            --surface2:  #181b22;
            --border:    #252830;
            --accent:    #e8ff47;
            --accent2:   #47c6ff;
            --danger:    #ff4757;
            --success:   #2ed573;
            --text:      #e8eaf0;
            --muted:     #6b7280;
            --sidebar-w: 240px;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Space Mono', monospace;
            font-size: 13px;
            display: flex;
            min-height: 100vh;
        }

        /* ── SIDEBAR ── */
        .sidebar {
            width: var(--sidebar-w);
            background: var(--surface);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0; left: 0; bottom: 0;
            z-index: 100;
        }

        .sidebar-logo {
            padding: 28px 24px 20px;
            border-bottom: 1px solid var(--border);
        }
        .sidebar-logo .logo-mark {
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 20px;
            color: var(--accent);
            letter-spacing: -0.5px;
        }
        .sidebar-logo .logo-sub {
            font-size: 10px;
            color: var(--muted);
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-top: 2px;
        }

        .nav-section {
            padding: 20px 12px 8px;
            flex: 1;
        }
        .nav-label {
            font-size: 9px;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--muted);
            padding: 0 12px;
            margin-bottom: 6px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 8px;
            text-decoration: none;
            color: var(--muted);
            transition: all 0.15s;
            margin-bottom: 2px;
        }
        .nav-item:hover {
            background: var(--surface2);
            color: var(--text);
        }
        .nav-item.active {
            background: var(--accent);
            color: #000;
        }
        .nav-item .icon { font-size: 16px; width: 20px; text-align: center; }
        .nav-item .label { font-family: 'Syne', sans-serif; font-weight: 600; font-size: 13px; }

        .sidebar-footer {
            padding: 16px 12px;
            border-top: 1px solid var(--border);
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px;
        }
        .avatar {
            width: 32px; height: 32px;
            border-radius: 50%;
            background: var(--accent);
            color: #000;
            display: flex; align-items: center; justify-content: center;
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 13px;
        }
        .user-name { font-size: 12px; color: var(--text); }
        .user-role { font-size: 10px; color: var(--muted); }
        .logout-btn {
            display: flex; align-items: center; gap: 8px;
            padding: 8px 12px;
            border-radius: 8px;
            color: var(--danger);
            text-decoration: none;
            margin-top: 4px;
            font-size: 12px;
            transition: background 0.15s;
        }
        .logout-btn:hover { background: rgba(255,71,87,0.1); }

        /* ── MAIN ── */
        .main {
            margin-left: var(--sidebar-w);
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .topbar {
            background: var(--surface);
            border-bottom: 1px solid var(--border);
            padding: 16px 32px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .page-title {
            font-family: 'Syne', sans-serif;
            font-weight: 700;
            font-size: 18px;
        }
        .breadcrumb {
            font-size: 11px;
            color: var(--muted);
            margin-top: 2px;
        }
        .topbar-actions { display: flex; gap: 8px; align-items: center; }

        .content {
            padding: 32px;
            flex: 1;
        }

        /* ── COMPOSANTS ── */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            border-radius: 8px;
            font-family: 'Space Mono', monospace;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
            text-decoration: none;
            border: none;
            transition: all 0.15s;
        }
        .btn-primary { background: var(--accent); color: #000; }
        .btn-primary:hover { background: #d4e83f; }
        .btn-secondary { background: var(--surface2); color: var(--text); border: 1px solid var(--border); }
        .btn-secondary:hover { border-color: var(--accent); color: var(--accent); }
        .btn-danger { background: transparent; color: var(--danger); border: 1px solid var(--danger); }
        .btn-danger:hover { background: var(--danger); color: #fff; }
        .btn-sm { padding: 5px 10px; font-size: 11px; }

        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 24px;
        }
        .card-title {
            font-family: 'Syne', sans-serif;
            font-weight: 700;
            font-size: 15px;
            margin-bottom: 20px;
            padding-bottom: 14px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        table { width: 100%; border-collapse: collapse; }
        thead tr { border-bottom: 2px solid var(--border); }
        th {
            text-align: left;
            padding: 10px 14px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: var(--muted);
        }
        td { padding: 12px 14px; border-bottom: 1px solid var(--border); vertical-align: middle; }
        tbody tr:hover { background: var(--surface2); }
        tbody tr:last-child td { border-bottom: none; }

        .badge {
            display: inline-flex;
            align-items: center;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .badge-success { background: rgba(46,213,115,0.15); color: var(--success); }
        .badge-danger  { background: rgba(255,71,87,0.15);  color: var(--danger); }
        .badge-info    { background: rgba(71,198,255,0.15); color: var(--accent2); }
        .badge-warn    { background: rgba(255,193,7,0.15);  color: #ffc107; }

        .form-group { margin-bottom: 18px; }
        .form-label {
            display: block;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--muted);
            margin-bottom: 8px;
        }
        .form-control {
            width: 100%;
            background: var(--bg);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            padding: 10px 14px;
            font-family: 'Space Mono', monospace;
            font-size: 12px;
            transition: border-color 0.15s;
        }
        .form-control:focus { outline: none; border-color: var(--accent); }

        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 12px;
        }
        .alert-success { background: rgba(46,213,115,0.1); border: 1px solid var(--success); color: var(--success); }
        .alert-error   { background: rgba(255,71,87,0.1);  border: 1px solid var(--danger);  color: var(--danger); }

        .stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; margin-bottom: 28px; }
        .stat-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
        }
        .stat-value {
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 32px;
            color: var(--accent);
            line-height: 1;
        }
        .stat-label { font-size: 11px; color: var(--muted); margin-top: 6px; text-transform: uppercase; letter-spacing: 1px; }

        .file-icon { font-size: 18px; }
        .ext-pdf { color: #ff6b6b; }
        .ext-img { color: #a29bfe; }
        .ext-doc { color: #74b9ff; }
        .ext-zip { color: #ffeaa7; }
        .ext-other{ color: var(--muted); }

        .modal-overlay {
            display: none;
            position: fixed; inset: 0;
            background: rgba(0,0,0,0.7);
            z-index: 200;
            align-items: center;
            justify-content: center;
        }
        .modal-overlay.show { display: flex; }
        .modal {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            width: 480px;
            max-width: 95vw;
        }
        .modal-title {
            font-family: 'Syne', sans-serif;
            font-weight: 700;
            font-size: 17px;
            margin-bottom: 24px;
        }
        .modal-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 24px; }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--muted);
        }
        .empty-state .icon { font-size: 48px; margin-bottom: 16px; opacity: 0.4; }
        .empty-state p { font-size: 13px; }
    </style>
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-logo">
        <div class="logo-mark">⬡ AdminPanel</div>
        <div class="logo-sub">v2.0 — Classic ASP</div>
    </div>
    <nav class="nav-section">
        <div class="nav-label">Navigation</div>
        <a href="index.asp" class="nav-item <%= IIf(activeTab="dashboard","active","") %>">
            <span class="icon">◈</span><span class="label">Dashboard</span>
        </a>
        <a href="utilisateurs.asp" class="nav-item <%= IIf(activeTab="users","active","") %>">
            <span class="icon">◉</span><span class="label">Utilisateurs</span>
        </a>
        <a href="uploads.asp" class="nav-item <%= IIf(activeTab="uploads","active","") %>">
            <span class="icon">◫</span><span class="label">Fichiers</span>
        </a>
        <a href="historique.asp" class="nav-item <%= IIf(activeTab="historique","active","") %>">
            <span class="icon">◷</span><span class="label">Historique</span>
        </a>
    </nav>
    <div class="sidebar-footer">
        <div class="user-info">
            <div class="avatar"><%= Left(Session("admin_login"), 1) %></div>
            <div>
                <div class="user-name"><%= Session("admin_login") %></div>
                <div class="user-role">Administrateur</div>
            </div>
        </div>
        <a href="logout.asp" class="logout-btn">⊗ Déconnexion</a>
    </div>
</aside>

<main class="main">
    <div class="topbar">
        <div>
            <div class="page-title"><%= pageTitle %></div>
            <div class="breadcrumb">Admin / <%= pageTitle %></div>
        </div>
        <div class="topbar-actions">

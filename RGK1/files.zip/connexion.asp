<%
' ============================================================
' connexion.asp - Connexion à la base de données
' ============================================================
Dim oConn
Set oConn = Server.CreateObject("ADODB.Connection")

' --- Adapter selon votre SGBD ---
' Option 1 : Access (.mdb)
' oConn.Open "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Server.MapPath("/db/admin.mdb")

' Option 2 : SQL Server
oConn.Open "Provider=SQLOLEDB;Server=localhost;Database=admin_db;UID=sa;PWD=motdepasse;"

' Option 3 : MySQL via ODBC
' oConn.Open "Driver={MySQL ODBC 8.0 ANSI Driver};Server=localhost;Database=admin_db;User=root;Password=motdepasse;"
%>

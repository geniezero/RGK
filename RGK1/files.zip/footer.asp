    </div><!-- /.content -->
</main><!-- /.main -->

<script>
function ouvrirModal(id) {
    document.getElementById(id).classList.add('show');
}
function fermerModal(id) {
    document.getElementById(id).classList.remove('show');
}
function confirmerSuppression(url, nom) {
    if (confirm('Supprimer « ' + nom + ' » ? Cette action est irréversible.')) {
        window.location.href = url;
    }
}
</script>
</body>
</html>

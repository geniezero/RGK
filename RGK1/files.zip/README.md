# AdminPanel — Interface d'administration ASP Classic

## Arborescence du projet

```
admin/                          ← Racine du back-office (ex: /inetpub/wwwroot/admin/)
│
├── login.asp                   ← Page de connexion (accès public)
├── logout.asp                  ← Destruction de session → redirect login
├── index.asp                   ← Tableau de bord (stats, activité récente)
│
├── utilisateurs.asp            ← CRUD complet des comptes utilisateurs
│   ├── Lister / rechercher
│   ├── Créer (modal)
│   ├── Éditer (modal)
│   ├── Activer / Désactiver
│   └── Supprimer
│
├── uploads.asp                 ← Gestion des fichiers stockés
│   ├── Lister avec filtres (extension, recherche)
│   ├── Modal d'upload (multipart/form-data)
│   ├── Télécharger
│   └── Supprimer (fichier physique + BDD)
│
├── uploads_process.asp         ← Traitement POST de l'upload (Persits ASPUpload)
│
├── historique.asp              ← Journal "qui a uploadé quoi"
│   ├── Tableau paginé (15 lignes / page)
│   ├── Filtres : utilisateur, extension, plage de dates, recherche libre
│   ├── Stats par utilisateur (nb fichiers + volume)
│   └── Pagination avec contexte
│
├── schema.sql                  ← Script SQL (tables + données de démo)
│
├── includes/                   ← Fichiers réutilisables (SSI)
│   ├── auth.asp                ← Vérification session + helpers (HtmlEncode, FormatDate, FormatTaille)
│   ├── connexion.asp           ← Connexion ADODB (SQL Server / Access / MySQL)
│   ├── header.asp              ← <html> + CSS + sidebar + topbar (début)
│   ├── footer_top.asp          ← Ferme la topbar, ouvre .content
│   └── footer.asp              ← Ferme .content + JS commun + </html>
│
└── uploads/                    ← Répertoire de stockage des fichiers uploadés
    └── (fichiers...)           ← Nommage : YYYYMMDD_HHmmss_nomoriginal.ext
```

---

## Technologies

| Couche        | Technologie                        |
|---------------|------------------------------------|
| Serveur web   | IIS 6+ (Windows Server)            |
| Langage       | ASP Classic (VBScript)             |
| Base de données| SQL Server 2012+ (ou Access/MySQL) |
| Upload         | Persits ASPUpload (composant COM)  |
| Fonts          | Google Fonts (Syne + Space Mono)   |
| CSS            | Variables CSS + Grid/Flex vanilla  |

---

## Installation

### 1. Déployer les fichiers
Copier le dossier `admin/` dans votre répertoire IIS, par exemple :
```
C:\inetpub\wwwroot\admin\
```

### 2. Base de données
Exécuter `schema.sql` sur votre instance SQL Server :
```sql
-- Dans SQL Server Management Studio :
USE votre_base;
GO
-- coller le contenu de schema.sql
```

### 3. Adapter la connexion
Éditer `includes/connexion.asp` et choisir la chaîne de connexion adaptée à votre SGBD.

### 4. Installer ASPUpload (pour les uploads)
- Télécharger : https://www.aspupload.com/download.html
- Installer sur le serveur IIS
- Le composant `Persits.Upload` doit être enregistré dans COM+

**Alternative gratuite (pure ASP) :**
Remplacer `uploads_process.asp` par une implémentation utilisant
[Free ASP Upload](http://www.freeaspupload.net/) ou une lecture `Request.BinaryRead`.

### 5. Permissions IIS
Le compte IIS_IUSRS doit avoir les droits **Écriture** sur le dossier `uploads/`.

### 6. Se connecter
Naviguer vers `http://votre-serveur/admin/login.asp`
- Login : `admin`
- Mot de passe : `Admin123!`

> ⚠️ **En production** : hacher les mots de passe (SHA-256 ou bcrypt via composant COM),
> déplacer le dossier `uploads/` hors de la racine web, activer HTTPS.

---

## Structure de la base de données

### Table `utilisateurs`
| Champ          | Type         | Description                        |
|----------------|--------------|------------------------------------|
| id             | INT (PK)     | Identifiant auto-incrémenté        |
| login          | VARCHAR(50)  | Identifiant unique de connexion    |
| email          | VARCHAR(150) | Adresse email                      |
| mdp_hash       | VARCHAR(255) | Hash du mot de passe               |
| role           | VARCHAR(20)  | `user` ou `admin`                  |
| actif          | BIT          | Compte activé (1) ou non (0)       |
| date_creation  | DATETIME     | Date de création du compte         |

### Table `fichiers`
| Champ           | Type         | Description                        |
|-----------------|--------------|------------------------------------|
| id              | INT (PK)     | Identifiant auto-incrémenté        |
| nom_fichier     | VARCHAR(255) | Nom original du fichier            |
| nom_stockage    | VARCHAR(255) | Nom unique sur le disque           |
| chemin_physique | VARCHAR(500) | Chemin absolu serveur              |
| taille          | BIGINT       | Taille en octets                   |
| description     | VARCHAR(500) | Description optionnelle            |
| utilisateur_id  | INT (FK)     | Référence vers `utilisateurs.id`   |
| date_upload     | DATETIME     | Date et heure de l'upload          |

---

## Fonctionnalités par onglet

### 🗲 Dashboard (`index.asp`)
- Compteurs : nb utilisateurs, nb fichiers, volume total, uploads du jour
- Tableau des 8 dernières activités
- Raccourcis vers les autres sections

### ◉ Utilisateurs (`utilisateurs.asp`)
- Liste paginée avec recherche (login / email)
- Création via modal (login, email, mot de passe, rôle)
- Édition via modal (tous les champs + statut actif/inactif)
- Bascule rapide actif ↔ inactif
- Suppression avec confirmation JavaScript
- Protection : impossible de supprimer son propre compte

### ◫ Fichiers (`uploads.asp`)
- Liste avec filtres rapides par extension (PDF, IMG, DOCX, ZIP)
- Recherche libre (nom de fichier ou auteur)
- Upload via modal multipart (validation extension + taille)
- Téléchargement direct
- Suppression : fichier physique + enregistrement BDD

### ◷ Historique (`historique.asp`)
- Vue croisée fichier × utilisateur
- Filtres cumulables : utilisateur, extension, plage de dates, texte libre
- Statistiques par utilisateur (nb fichiers + volume)
- Pagination (15 lignes/page) avec navigation contextuelle
- Clic sur un badge utilisateur → filtre automatique par cet utilisateur

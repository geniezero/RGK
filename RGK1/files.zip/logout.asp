<%@ Language="VBScript" %>
<%
' ============================================================
' logout.asp - Déconnexion et destruction de session
' ============================================================
Session.Abandon
Response.Redirect "login.asp"
%>

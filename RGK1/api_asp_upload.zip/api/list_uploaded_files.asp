<%@ Language=VBScript %>
<%
Option Explicit
Response.Buffer = True
%>
<!--#include file="db.asp"-->
<!--#include file="json_utils.asp"-->
<%
Dim cn, rs, sql, json, isFirst
On Error Resume Next

If UCase(Request.ServerVariables("REQUEST_METHOD")) <> "GET" Then
  WriteError 405, "Méthode non autorisée."
  Response.End
End If

Set cn = OpenConnection()
If Err.Number <> 0 Then
  WriteError 500, "Connexion base impossible : " & Err.Description
  Response.End
End If

sql = "SELECT id, file_name, file_size, mime_type, logical_folder, file_url, uploaded_at FROM uploaded_files ORDER BY uploaded_at DESC"
Set rs = cn.Execute(sql)
If Err.Number <> 0 Then
  CloseIfOpen rs
  CloseIfOpen cn
  WriteError 500, "Lecture impossible : " & Err.Description
  Response.End
End If

json = "{""files"":["
isFirst = True
Do Until rs.EOF
  If Not isFirst Then json = json & ","
  json = json & "{" & _
    """id"":" & CLng(rs("id")) & "," & _
    """file_name"":""" & JsonEscape(rs("file_name")) & """," & _
    """file_size"":" & CLng(rs("file_size")) & "," & _
    """mime_type"":""" & JsonEscape(rs("mime_type")) & """," & _
    """logical_folder"":""" & JsonEscape(rs("logical_folder")) & """," & _
    """file_url"":""" & JsonEscape(rs("file_url")) & """," & _
    """uploaded_at"":""" & JsonEscape(CStr(rs("uploaded_at"))) & """" & _
  "}"
  isFirst = False
  rs.MoveNext
Loop
json = json & "]}"

CloseIfOpen rs
CloseIfOpen cn
WriteJson 200, json
%>

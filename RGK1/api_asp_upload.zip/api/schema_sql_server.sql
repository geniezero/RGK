CREATE TABLE uploaded_files (
    id INT IDENTITY(1,1) PRIMARY KEY,
    file_name        NVARCHAR(255) NOT NULL,
    file_size        BIGINT NOT NULL,
    mime_type        NVARCHAR(150) NULL,
    logical_folder   NVARCHAR(255) NOT NULL,
    physical_path    NVARCHAR(1000) NOT NULL,
    file_url         NVARCHAR(1000) NOT NULL,
    uploaded_at      DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE INDEX IX_uploaded_files_uploaded_at ON uploaded_files(uploaded_at DESC);
CREATE INDEX IX_uploaded_files_logical_folder ON uploaded_files(logical_folder);

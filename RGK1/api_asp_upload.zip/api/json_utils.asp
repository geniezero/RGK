<%
Option Explicit

Sub WriteJson(ByVal statusCode, ByVal jsonText)
  Response.ContentType = "application/json"
  Response.Status = CStr(statusCode) & " " & HttpStatusLabel(statusCode)
  Response.Write jsonText
End Sub

Function HttpStatusLabel(ByVal code)
  Select Case CLng(code)
    Case 200: HttpStatusLabel = "OK"
    Case 201: HttpStatusLabel = "Created"
    Case 400: HttpStatusLabel = "Bad Request"
    Case 404: HttpStatusLabel = "Not Found"
    Case 405: HttpStatusLabel = "Method Not Allowed"
    Case 413: HttpStatusLabel = "Payload Too Large"
    Case 500: HttpStatusLabel = "Internal Server Error"
    Case Else: HttpStatusLabel = "OK"
  End Select
End Function

Function JsonEscape(ByVal value)
  Dim s
  If IsNull(value) Then
    JsonEscape = ""
    Exit Function
  End If
  s = CStr(value)
  s = Replace(s, "\\", "\\\\")
  s = Replace(s, Chr(34), "\"")
  s = Replace(s, vbCrLf, "\n")
  s = Replace(s, vbCr, "\n")
  s = Replace(s, vbLf, "\n")
  s = Replace(s, vbTab, "\t")
  JsonEscape = s
End Function

Sub WriteError(ByVal statusCode, ByVal message)
  WriteJson statusCode, "{""error"":""" & JsonEscape(message) & """}"
End Sub
%>

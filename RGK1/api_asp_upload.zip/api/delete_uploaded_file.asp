<%@ Language=VBScript %>
<%
Option Explicit
Response.Buffer = True
%>
<!--#include file="db.asp"-->
<!--#include file="json_utils.asp"-->
<!--#include file="upload_utils.asp"-->
<%
Dim id, cn, rs, sql, physicalPath
On Error Resume Next

If UCase(Request.ServerVariables("REQUEST_METHOD")) <> "POST" Then
  WriteError 405, "Méthode non autorisée."
  Response.End
End If

id = Trim(Request("id"))
If id = "" Or Not IsNumeric(id) Then
  WriteError 400, "Paramètre id invalide."
  Response.End
End If

Set cn = OpenConnection()
sql = "SELECT id, physical_path FROM uploaded_files WHERE id = " & CLng(id)
Set rs = cn.Execute(sql)
If rs.EOF Then
  CloseIfOpen rs
  CloseIfOpen cn
  WriteError 404, "Fichier introuvable."
  Response.End
End If

physicalPath = rs("physical_path")
CloseIfOpen rs

sql = "DELETE FROM uploaded_files WHERE id = " & CLng(id)
cn.Execute sql
If Err.Number <> 0 Then
  CloseIfOpen cn
  WriteError 500, "Suppression base impossible : " & Err.Description
  Response.End
End If

DeleteFileIfExists physicalPath
CloseIfOpen cn
WriteJson 200, "{""success"":true,""id"":" & CLng(id) & "}"
%>

<%
Option Explicit
<!--#include file="config.asp"-->

Class UploadedFile
  Public FieldName
  Public FileName
  Public ContentType
  Public TempPath
  Public Size
End Class

Class ParsedUpload
  Public Fields
  Public Files

  Private Sub Class_Initialize()
    Set Fields = Server.CreateObject("Scripting.Dictionary")
    Set Files = Server.CreateObject("Scripting.Dictionary")
  End Sub
End Class

Function SanitizeFolder(ByVal folder)
  Dim clean
  clean = Trim(CStr(folder))
  clean = Replace(clean, "\\", "/")
  Do While InStr(clean, "//") > 0
    clean = Replace(clean, "//", "/")
  Loop
  If Left(clean, 1) = "/" Then clean = Mid(clean, 2)
  If Right(clean, 1) = "/" Then clean = Left(clean, Len(clean) - 1)
  If clean = "" Then clean = "uploads"
  If InStr(clean, "..") > 0 Then clean = "uploads"
  SanitizeFolder = clean
End Function

Function FileExtension(ByVal fileName)
  Dim p
  p = InStrRev(fileName, ".")
  If p > 0 Then
    FileExtension = LCase(Mid(fileName, p + 1))
  Else
    FileExtension = ""
  End If
End Function

Function SafeFileName(ByVal fileName)
  Dim s, badChars, i
  s = CStr(fileName)
  badChars = Array("\\", "/", ":", "*", "?", Chr(34), "<", ">", "|")
  For i = 0 To UBound(badChars)
    s = Replace(s, badChars(i), "_")
  Next
  SafeFileName = s
End Function

Function UniqueFileName(ByVal folderPath, ByVal originalFileName)
  Dim fso, baseName, ext, p, candidate, n
  Set fso = Server.CreateObject("Scripting.FileSystemObject")

  p = InStrRev(originalFileName, ".")
  If p > 0 Then
    baseName = Left(originalFileName, p - 1)
    ext = Mid(originalFileName, p)
  Else
    baseName = originalFileName
    ext = ""
  End If

  candidate = originalFileName
  n = 1
  Do While fso.FileExists(folderPath & "\\" & candidate)
    candidate = baseName & "_" & n & ext
    n = n + 1
  Loop
  UniqueFileName = candidate
End Function

Sub EnsureFolderExists(ByVal fullPath)
  Dim fso, parts, currentPath, i
  Set fso = Server.CreateObject("Scripting.FileSystemObject")
  If fso.FolderExists(fullPath) Then Exit Sub

  parts = Split(fullPath, "\\")
  currentPath = parts(0)
  For i = 1 To UBound(parts)
    currentPath = currentPath & "\\" & parts(i)
    If Not fso.FolderExists(currentPath) Then
      fso.CreateFolder currentPath
    End If
  Next
End Sub

Function BuildPhysicalFolder(ByVal logicalFolder)
  Dim rootFolder
  logicalFolder = SanitizeFolder(logicalFolder)
  rootFolder = BASE_UPLOAD_PHYSICAL_PATH
  If Right(rootFolder, 1) = "\\" Then rootFolder = Left(rootFolder, Len(rootFolder)-1)
  BuildPhysicalFolder = rootFolder & "\\" & Replace(logicalFolder, "/", "\\")
End Function

Function BuildPublicUrl(ByVal logicalFolder, ByVal fileName)
  Dim folder, base
  folder = SanitizeFolder(logicalFolder)
  base = BASE_UPLOAD_PUBLIC_URL
  If Right(base, 1) = "/" Then base = Left(base, Len(base)-1)
  BuildPublicUrl = base & "/" & folder & "/" & fileName
End Function

Function ReadUpload()
  Dim result, totalBytes, boundary, binData
  Set result = New ParsedUpload

  totalBytes = CLng(Request.TotalBytes)
  If totalBytes <= 0 Then
    Set ReadUpload = result
    Exit Function
  End If

  binData = Request.BinaryRead(totalBytes)
  boundary = GetBoundaryFromContentType(Request.ServerVariables("HTTP_CONTENT_TYPE"))
  If boundary = "" Then
    Set ReadUpload = result
    Exit Function
  End If

  ParseMultipart result, binData, boundary
  Set ReadUpload = result
End Function

Function GetBoundaryFromContentType(ByVal contentType)
  Dim token, arr, i
  arr = Split(contentType, ";")
  For i = 0 To UBound(arr)
    token = Trim(arr(i))
    If LCase(Left(token, 9)) = "boundary=" Then
      GetBoundaryFromContentType = "--" & Mid(token, 10)
      Exit Function
    End If
  Next
  GetBoundaryFromContentType = ""
End Function

Sub ParseMultipart(ByRef result, ByVal binData, ByVal boundary)
  Dim stream, raw, parts, i
  Set stream = Server.CreateObject("ADODB.Stream")
  stream.Type = 1
  stream.Open
  stream.Write binData
  stream.Position = 0
  stream.Type = 2
  stream.Charset = "iso-8859-1"
  raw = stream.ReadText
  stream.Close
  Set stream = Nothing

  parts = Split(raw, boundary)
  For i = 1 To UBound(parts) - 1
    ParsePart result, parts(i)
  Next
End Sub

Sub ParsePart(ByRef result, ByVal partText)
  Dim headerEnd, headers, body, disposition, fieldName, fileName, contentType, lines, i
  If Left(partText, 2) = vbCrLf Then partText = Mid(partText, 3)
  headerEnd = InStr(partText, vbCrLf & vbCrLf)
  If headerEnd = 0 Then Exit Sub

  headers = Left(partText, headerEnd - 1)
  body = Mid(partText, headerEnd + 4)
  If Right(body, 2) = vbCrLf Then body = Left(body, Len(body) - 2)

  lines = Split(headers, vbCrLf)
  disposition = ""
  contentType = ""

  For i = 0 To UBound(lines)
    If LCase(Left(lines(i), 19)) = "content-disposition" Then disposition = lines(i)
    If LCase(Left(lines(i), 12)) = "content-type" Then contentType = Trim(Split(lines(i), ":")(1))
  Next

  fieldName = ExtractQuotedValue(disposition, "name")
  fileName = ExtractQuotedValue(disposition, "filename")

  If fileName <> "" Then
    Dim uf, tempFilePath
    Set uf = New UploadedFile
    uf.FieldName = fieldName
    uf.FileName = ExtractLeafFileName(fileName)
    uf.ContentType = contentType
    uf.Size = LenB(StrConv(body, vbFromUnicode))
    tempFilePath = SaveTempBody(body, uf.FileName)
    uf.TempPath = tempFilePath
    result.Files.Add fieldName, uf
  ElseIf fieldName <> "" Then
    result.Fields(fieldName) = body
  End If
End Sub

Function SaveTempBody(ByVal body, ByVal originalFileName)
  Dim tempFolder, fileName, stream
  tempFolder = Server.MapPath("./tmp_upload")
  EnsureFolderExists tempFolder
  fileName = Replace(Replace(Replace(CStr(Timer), ".", "_"), ":", "_"), ",", "_") & "_" & SafeFileName(originalFileName)

  Set stream = Server.CreateObject("ADODB.Stream")
  stream.Type = 2
  stream.Charset = "iso-8859-1"
  stream.Open
  stream.WriteText body
  stream.Position = 0
  stream.Type = 1
  stream.SaveToFile tempFolder & "\\" & fileName, 2
  stream.Close
  Set stream = Nothing

  SaveTempBody = tempFolder & "\\" & fileName
End Function

Function ExtractQuotedValue(ByVal headerLine, ByVal key)
  Dim pattern, re, matches
  Set re = New RegExp
  re.Pattern = key & "=""([^""]*)"""
  re.IgnoreCase = True
  re.Global = False
  If re.Test(headerLine) Then
    Set matches = re.Execute(headerLine)
    ExtractQuotedValue = matches(0).SubMatches(0)
  Else
    ExtractQuotedValue = ""
  End If
End Function

Function ExtractLeafFileName(ByVal fullName)
  Dim s, p
  s = Replace(fullName, "/", "\\")
  p = InStrRev(s, "\\")
  If p > 0 Then
    ExtractLeafFileName = Mid(s, p + 1)
  Else
    ExtractLeafFileName = s
  End If
End Function

Sub MoveFile(ByVal sourcePath, ByVal destinationPath)
  Dim fso
  Set fso = Server.CreateObject("Scripting.FileSystemObject")
  If fso.FileExists(destinationPath) Then fso.DeleteFile destinationPath, True
  fso.MoveFile sourcePath, destinationPath
End Sub

Sub DeleteFileIfExists(ByVal filePath)
  Dim fso
  Set fso = Server.CreateObject("Scripting.FileSystemObject")
  If fso.FileExists(filePath) Then fso.DeleteFile filePath, True
End Sub
%>

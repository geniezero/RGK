<%
Option Explicit
Response.CodePage = 65001
Response.CharSet = "utf-8"
Session.CodePage = 65001

' ==============================
' Configuration générale
' ==============================
Const DB_CONNECTION_STRING = "Provider=SQLOLEDB;Data Source=YOUR_SQL_SERVER;Initial Catalog=YOUR_DATABASE;User ID=YOUR_USER;Password=YOUR_PASSWORD;"
Const BASE_UPLOAD_PHYSICAL_PATH = "C:\\inetpub\\wwwroot\\yourapp\\uploads"
Const BASE_UPLOAD_PUBLIC_URL    = "/uploads"
Const MAX_UPLOAD_BYTES          = 52428800 ' 50 Mo

Function ApiBasePath()
  ApiBasePath = Replace(Request.ServerVariables("APPL_PHYSICAL_PATH"), "\\", "/")
End Function
%>

<%@ Language=VBScript %>
<%
Option Explicit
Response.Buffer = True
%>
<!--#include file="db.asp"-->
<!--#include file="json_utils.asp"-->
<!--#include file="upload_utils.asp"-->
<%
Dim upload, destinationFolder, cn, rs, sql
Dim uf, originalName, finalName, physicalFolder, physicalPath, publicUrl
Dim mimeType, fileSize, logicalFolder

On Error Resume Next

If UCase(Request.ServerVariables("REQUEST_METHOD")) <> "POST" Then
  WriteError 405, "Méthode non autorisée."
  Response.End
End If

If CLng(Request.TotalBytes) > MAX_UPLOAD_BYTES + 10240 Then
  WriteError 413, "Le payload dépasse la limite autorisée."
  Response.End
End If

Set upload = ReadUpload()
If upload.Files.Count = 0 Then
  WriteError 400, "Aucun fichier reçu. Le champ attendu est 'file'."
  Response.End
End If

If upload.Fields.Exists("destination_folder") Then
  destinationFolder = upload.Fields("destination_folder")
Else
  destinationFolder = "uploads"
End If
logicalFolder = SanitizeFolder(destinationFolder)

If upload.Files.Exists("file") Then
  Set uf = upload.Files("file")
Else
  Dim k
  For Each k In upload.Files.Keys
    Set uf = upload.Files(k)
    Exit For
  Next
End If

originalName = SafeFileName(uf.FileName)
If originalName = "" Then
  DeleteFileIfExists uf.TempPath
  WriteError 400, "Nom de fichier invalide."
  Response.End
End If

If uf.Size > MAX_UPLOAD_BYTES Then
  DeleteFileIfExists uf.TempPath
  WriteError 413, "Le fichier dépasse 50 Mo."
  Response.End
End If

physicalFolder = BuildPhysicalFolder(logicalFolder)
EnsureFolderExists physicalFolder
finalName = UniqueFileName(physicalFolder, originalName)
physicalPath = physicalFolder & "\\" & finalName
publicUrl = BuildPublicUrl(logicalFolder, finalName)
mimeType = uf.ContentType
fileSize = uf.Size

MoveFile uf.TempPath, physicalPath
If Err.Number <> 0 Then
  DeleteFileIfExists uf.TempPath
  WriteError 500, "Impossible d'enregistrer le fichier : " & Err.Description
  Response.End
End If

Set cn = OpenConnection()
If Err.Number <> 0 Then
  WriteError 500, "Connexion base impossible : " & Err.Description
  Response.End
End If

sql = "INSERT INTO uploaded_files (file_name, file_size, mime_type, logical_folder, physical_path, file_url, uploaded_at) " & _
      "VALUES ('" & SafeSqlString(finalName) & "', " & CLng(fileSize) & ", '" & SafeSqlString(mimeType) & "', '" & SafeSqlString(logicalFolder) & "', '" & SafeSqlString(physicalPath) & "', '" & SafeSqlString(publicUrl) & "', GETDATE()); " & _
      "SELECT CAST(SCOPE_IDENTITY() AS INT) AS new_id;"

Set rs = cn.Execute(sql)
If Err.Number <> 0 Then
  DeleteFileIfExists physicalPath
  CloseIfOpen rs
  CloseIfOpen cn
  WriteError 500, "Insertion base impossible : " & Err.Description
  Response.End
End If

WriteJson 201, "{""file"":{" & _
  """id"":" & CLng(rs("new_id")) & "," & _
  """file_name"":""" & JsonEscape(finalName) & """," & _
  """file_size"":" & CLng(fileSize) & "," & _
  """mime_type"":""" & JsonEscape(mimeType) & """," & _
  """logical_folder"":""" & JsonEscape(logicalFolder) & """," & _
  """file_url"":""" & JsonEscape(publicUrl) & """," & _
  """uploaded_at"":""" & JsonEscape(CStr(Now())) & """" & _
"}}"

CloseIfOpen rs
CloseIfOpen cn
%>

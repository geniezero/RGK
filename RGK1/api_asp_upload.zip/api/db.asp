<%
Option Explicit
<!--#include file="config.asp"-->

Function OpenConnection()
  Dim cn
  Set cn = Server.CreateObject("ADODB.Connection")
  cn.Open DB_CONNECTION_STRING
  Set OpenConnection = cn
End Function

Function SafeSqlString(ByVal s)
  If IsNull(s) Then
    SafeSqlString = ""
  Else
    SafeSqlString = Replace(CStr(s), "'", "''")
  End If
End Function

Sub CloseIfOpen(ByRef obj)
  On Error Resume Next
  If IsObject(obj) Then
    If TypeName(obj) = "Connection" Then
      If obj.State = 1 Then obj.Close
    ElseIf TypeName(obj) = "Recordset" Then
      If obj.State = 1 Then obj.Close
    End If
    Set obj = Nothing
  End If
  On Error GoTo 0
End Sub
%>

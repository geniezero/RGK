@echo off
REM Installe l application dans un environnement virtuel (.venv) - a lancer une seule fois
cd /d "%~dp0"
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
if not exist .venv (
    echo Creation de l environnement virtuel .venv ...
    %PY% -m venv .venv || (echo Python introuvable : installez-le depuis python.org en cochant "Add Python to PATH". & pause & exit /b 1)
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt || (echo Echec de l installation des dependances. & pause & exit /b 1)
echo.
echo Installation terminee. Lancez l application avec lancer.bat
pause

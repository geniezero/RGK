@echo off
REM Lance l application dans son environnement virtuel
cd /d "%~dp0"
if not exist .venv\Scripts\activate.bat (
    echo Environnement absent : lancez d abord installer.bat
    pause
    exit /b 1
)
call .venv\Scripts\activate.bat
streamlit run app.py

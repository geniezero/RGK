#!/usr/bin/env bash
# Installe l'application dans un environnement virtuel (.venv) — macOS / Linux
set -e
cd "$(dirname "$0")"
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo "Installation terminée. Lancez l'application avec ./lancer.sh"
